sap.ui.define(['sap/suite/ui/generic/template/lib/AppComponent'], function(AppComponent) {
    return AppComponent.extend("hedgeprofile.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
